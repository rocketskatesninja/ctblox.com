<div class="quiz-container" data-quiz-id="customer_experience_strategy_quiz">
    <h2 class="text-xl font-bold mb-4">Customer Experience Strategy Quiz</h2>
    <p class="mb-6">Test your understanding of creating an effective customer experience strategy for your business.</p>
    
    <form class="space-y-6 quiz-form">
        <!-- Question 1 -->
        <div class="quiz-question" data-question-id="1">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    What is the primary purpose of a customer experience (CX) vision statement?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-a" name="question1" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-a" class="font-medium text-gray-700 dark:text-gray-300">To create marketing materials that attract new customers</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-b" name="question1" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-b" class="font-medium text-gray-700 dark:text-gray-300">To serve as a North Star for all customer-related decisions</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-c" name="question1" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-c" class="font-medium text-gray-700 dark:text-gray-300">To establish pricing strategies for products and services</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-d" name="question1" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-d" class="font-medium text-gray-700 dark:text-gray-300">To define job responsibilities for customer service staff</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 2 -->
        <div class="quiz-question" data-question-id="2">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which of the following is NOT typically included in a customer journey map?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-a" name="question2" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-a" class="font-medium text-gray-700 dark:text-gray-300">Customer touchpoints with your business</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-b" name="question2" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-b" class="font-medium text-gray-700 dark:text-gray-300">Customer pain points at each stage</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-c" name="question2" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-c" class="font-medium text-gray-700 dark:text-gray-300">Employee salary information</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-d" name="question2" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-d" class="font-medium text-gray-700 dark:text-gray-300">Opportunities to enhance the experience</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 3 -->
        <div class="quiz-question" data-question-id="3">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which experience design principle focuses on making every interaction as straightforward as possible?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-a" name="question3" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-a" class="font-medium text-gray-700 dark:text-gray-300">Personalization</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-b" name="question3" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-b" class="font-medium text-gray-700 dark:text-gray-300">Transparency</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-c" name="question3" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-c" class="font-medium text-gray-700 dark:text-gray-300">Simplicity</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-d" name="question3" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-d" class="font-medium text-gray-700 dark:text-gray-300">Empowerment</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 4 -->
        <div class="quiz-question" data-question-id="4">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which metric measures customer loyalty based on likelihood to recommend?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-a" name="question4" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-a" class="font-medium text-gray-700 dark:text-gray-300">Net Promoter Score (NPS)</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-b" name="question4" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-b" class="font-medium text-gray-700 dark:text-gray-300">Customer Satisfaction (CSAT)</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-c" name="question4" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-c" class="font-medium text-gray-700 dark:text-gray-300">Customer Effort Score (CES)</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-d" name="question4" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-d" class="font-medium text-gray-700 dark:text-gray-300">Customer Lifetime Value (CLV)</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 5 -->
        <div class="quiz-question" data-question-id="5">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which of the following is most important for aligning your organization around your CX strategy?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-a" name="question5" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-a" class="font-medium text-gray-700 dark:text-gray-300">Implementing expensive technology solutions</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-b" name="question5" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-b" class="font-medium text-gray-700 dark:text-gray-300">Leadership commitment and employee empowerment</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-c" name="question5" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-c" class="font-medium text-gray-700 dark:text-gray-300">Focusing exclusively on customer acquisition</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-d" name="question5" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-d" class="font-medium text-gray-700 dark:text-gray-300">Restructuring the organization chart</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <div class="pt-5">
            <div class="flex justify-end">
                <button type="submit" class="submit-quiz ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Submit Answers
                </button>
            </div>
        </div>
    </form>
    
    <div class="quiz-results hidden mt-6">
        <div class="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">Quiz Results</h3>
                <div class="mt-2 max-w-xl text-sm text-gray-500 dark:text-gray-400">
                    <p class="results-message"></p>
                </div>
                <div class="mt-3 text-sm">
                    <button type="button" class="retake-quiz font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                        Retake Quiz
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Quiz answers
    const quizAnswers = {
        "1": "B", // To serve as a North Star for all customer-related decisions
        "2": "C", // Employee salary information
        "3": "C", // Simplicity
        "4": "A", // Net Promoter Score (NPS)
        "5": "B"  // Leadership commitment and employee empowerment
    };
    
    // Initialize the quiz using the standardized quiz system
    if (typeof initQuiz === 'function') {
        initQuiz('customer_experience_strategy_quiz', quizAnswers);
    } else {
        console.error('Quiz system not loaded. Please refresh the page.');
    }
});
</script>
