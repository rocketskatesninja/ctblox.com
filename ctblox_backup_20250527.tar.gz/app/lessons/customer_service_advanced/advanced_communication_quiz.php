<div class="quiz-container" data-quiz-id="advanced_communication_quiz">
    <h2 class="text-xl font-bold mb-4">Advanced Communication Techniques Quiz</h2>
    <p class="mb-6">Test your understanding of advanced communication techniques for customer service.</p>
    
    <form class="space-y-6 quiz-form">
        <!-- Question 1 -->
        <div class="quiz-question" data-question-id="1">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    What is the HEARD technique primarily used for in customer service?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-a" name="question1" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-a" class="font-medium text-gray-700 dark:text-gray-300">Improving active listening skills</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-b" name="question1" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-b" class="font-medium text-gray-700 dark:text-gray-300">De-escalating tense customer situations</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-c" name="question1" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-c" class="font-medium text-gray-700 dark:text-gray-300">Personalizing customer interactions</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q1-d" name="question1" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q1-d" class="font-medium text-gray-700 dark:text-gray-300">Identifying customer communication styles</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 2 -->
        <div class="quiz-question" data-question-id="2">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which of the following is NOT one of the four main customer communication styles discussed in the chapter?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-a" name="question2" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-a" class="font-medium text-gray-700 dark:text-gray-300">Analytical</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-b" name="question2" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-b" class="font-medium text-gray-700 dark:text-gray-300">Expressive</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-c" name="question2" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-c" class="font-medium text-gray-700 dark:text-gray-300">Passive</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q2-d" name="question2" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q2-d" class="font-medium text-gray-700 dark:text-gray-300">Driver</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 3 -->
        <div class="quiz-question" data-question-id="3">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Advanced active listening includes which of the following elements?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-a" name="question3" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-a" class="font-medium text-gray-700 dark:text-gray-300">Interrupting to correct customer misconceptions</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-b" name="question3" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-b" class="font-medium text-gray-700 dark:text-gray-300">Focusing on company policies while the customer speaks</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-c" name="question3" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-c" class="font-medium text-gray-700 dark:text-gray-300">Recognizing emotional undertones in customer communication</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q3-d" name="question3" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q3-d" class="font-medium text-gray-700 dark:text-gray-300">Preparing your response while the customer is speaking</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 4 -->
        <div class="quiz-question" data-question-id="4">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    What is "anticipatory service" in the context of personalization?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-a" name="question4" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-a" class="font-medium text-gray-700 dark:text-gray-300">Addressing customer needs before they explicitly ask</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-b" name="question4" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-b" class="font-medium text-gray-700 dark:text-gray-300">Preparing customers for service delays</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-c" name="question4" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-c" class="font-medium text-gray-700 dark:text-gray-300">Creating a waiting list for premium services</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q4-d" name="question4" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q4-d" class="font-medium text-gray-700 dark:text-gray-300">Scheduling future appointments automatically</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <!-- Question 5 -->
        <div class="quiz-question" data-question-id="5">
            <fieldset>
                <legend class="text-base font-medium text-gray-900 dark:text-white mb-2">
                    Which of the following is a warning sign that a customer interaction is escalating?
                </legend>
                <div class="mt-2 space-y-2">
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-a" name="question5" type="radio" value="A" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-a" class="font-medium text-gray-700 dark:text-gray-300">Asking detailed questions about your products</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-b" name="question5" type="radio" value="B" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-b" class="font-medium text-gray-700 dark:text-gray-300">Repetitive statements or complaints</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-c" name="question5" type="radio" value="C" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-c" class="font-medium text-gray-700 dark:text-gray-300">Taking notes during your conversation</label>
                        </div>
                    </div>
                    <div class="flex items-start">
                        <div class="flex items-center h-5">
                            <input id="q5-d" name="question5" type="radio" value="D" class="focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300 dark:border-gray-600">
                        </div>
                        <div class="ml-3 text-sm">
                            <label for="q5-d" class="font-medium text-gray-700 dark:text-gray-300">Requesting to speak with the same representative</label>
                        </div>
                    </div>
                </div>
            </fieldset>
            <div class="answer-feedback hidden mt-2"></div>
        </div>
        
        <div class="pt-5">
            <div class="flex justify-end">
                <button type="submit" class="submit-quiz ml-3 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                    Submit Answers
                </button>
            </div>
        </div>
    </form>
    
    <div class="quiz-results hidden mt-6">
        <div class="bg-white dark:bg-gray-800 shadow overflow-hidden sm:rounded-lg">
            <div class="px-4 py-5 sm:p-6">
                <h3 class="text-lg leading-6 font-medium text-gray-900 dark:text-white">Quiz Results</h3>
                <div class="mt-2 max-w-xl text-sm text-gray-500 dark:text-gray-400">
                    <p class="results-message"></p>
                </div>
                <div class="mt-3 text-sm">
                    <button type="button" class="retake-quiz font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300">
                        Retake Quiz
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Quiz answers
    const quizAnswers = {
        "1": "B", // De-escalating tense customer situations
        "2": "C", // Passive (not one of the styles)
        "3": "C", // Recognizing emotional undertones
        "4": "A", // Addressing customer needs before they explicitly ask
        "5": "B"  // Repetitive statements or complaints
    };
    
    // Initialize the quiz using the standardized quiz system
    if (typeof initQuiz === 'function') {
        initQuiz('advanced_communication_quiz', quizAnswers);
    } else {
        console.error('Quiz system not loaded. Please refresh the page.');
    }
});
</script>
